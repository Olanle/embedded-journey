const uint8_t LED_PIN = LED_BUILTIN;  

const uint16_t pattern[] = {100, 100, 300, 300, 100};


const uint16_t sos[] = {
  200, 200, 200, 200, 200, 600,   
  600, 200, 600, 200, 600, 600,   
  200, 200, 200, 200, 200         
};

void play_pattern(const uint16_t *p, uint8_t n) {
  for (uint8_t i = 0; i < n; i++) {
    digitalWrite(LED_PIN, (i % 2 == 0) ? HIGH : LOW); 
    delay(p[i]);
  }
  digitalWrite(LED_PIN, LOW);  
}

void setup() {
  pinMode(LED_PIN, OUTPUT);
}

void loop() {
  play_pattern(pattern, sizeof(pattern) / sizeof(pattern[0]));
  delay(1000);
  play_pattern(sos, sizeof(sos) / sizeof(sos[0]));
  delay(2000);
}